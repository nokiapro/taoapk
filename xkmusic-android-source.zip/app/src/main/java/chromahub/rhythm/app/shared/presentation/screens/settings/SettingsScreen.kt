/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package chromahub.rhythm.app.shared.presentation.screens.settings

import chromahub.rhythm.app.shared.presentation.components.bottomsheets.AdaptiveSheetScrollContainer
import chromahub.rhythm.app.shared.presentation.components.bottomsheets.RhythmAdaptiveModalSheet
import chromahub.rhythm.app.shared.presentation.components.bottomsheets.SheetAdaptiveType
import chromahub.rhythm.app.shared.presentation.components.bottomsheets.StandardBottomSheetHeader
import chromahub.rhythm.app.shared.presentation.components.bottomsheets.groupedBottomSheetItemShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

import chromahub.rhythm.app.shared.presentation.components.icons.RhythmIcons
import chromahub.rhythm.app.shared.presentation.components.icons.MaterialSymbolIcon
import chromahub.rhythm.app.shared.presentation.components.icons.Icon

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.SpringSpec
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.util.lerp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlin.math.absoluteValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import chromahub.rhythm.app.shared.data.repository.PlaybackStatsRepository
import chromahub.rhythm.app.shared.presentation.navigation.RhythmGuardRiskLevel
import chromahub.rhythm.app.shared.presentation.navigation.rhythmGuardResolveRiskLevel
import androidx.compose.ui.draw.clip
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetState
import androidx.compose.material3.SheetValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.runtime.mutableIntStateOf
import chromahub.rhythm.app.R
import chromahub.rhythm.app.BuildConfig
import chromahub.rhythm.app.shared.presentation.components.common.CollapsibleHeaderScreen
import chromahub.rhythm.app.ui.utils.LazyListStateSaver
import chromahub.rhythm.app.ui.LocalMiniPlayerPadding
import chromahub.rhythm.app.shared.data.model.AppSettings
import chromahub.rhythm.app.features.local.presentation.components.settings.LanguageSwitcherBottomSheet
import chromahub.rhythm.app.shared.presentation.components.dialogs.FdroidUpdateWarningDialog
import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalConfiguration
import chromahub.rhythm.app.ui.theme.RhythmTheme
import chromahub.rhythm.app.util.HapticUtils
import chromahub.rhythm.app.util.HapticType
import androidx.lifecycle.viewmodel.compose.viewModel
import chromahub.rhythm.app.shared.presentation.components.player.SleepTimerBottomSheetNew
import chromahub.rhythm.app.features.local.presentation.navigation.Screen
import chromahub.rhythm.app.features.local.presentation.viewmodel.MusicViewModel
import chromahub.rhythm.app.shared.presentation.components.Material3SettingsGroup
import chromahub.rhythm.app.shared.presentation.components.Material3SettingsItem
import androidx.compose.ui.res.stringResource
import chromahub.rhythm.app.util.windowScreenWidthDp
import chromahub.rhythm.app.util.windowScreenHeightDp

import chromahub.rhythm.app.shared.presentation.components.SettingsBadgePalette
import chromahub.rhythm.app.shared.presentation.components.SettingsPalettes

// Define routes for navigation
object SettingsRoutes {
    const val NOTIFICATIONS = "notifications_settings"
    const val LABS = "labs_settings"
    const val EXPERIMENTAL_FEATURES = LABS
    const val ABOUT = "about_screen"
    const val UPDATES = "updates_screen"
    const val MEDIA_SCAN = "media_scan_settings"
    const val ARTIST_SEPARATORS = "artist_separators_settings"
    const val PLAYLISTS = "playlist_settings"
    const val DEFAULT_PLAYLISTS = "default_playlists_settings"
    const val API_MANAGEMENT = "api_management_settings"
    const val CACHE_MANAGEMENT = "cache_management_settings"
    const val BACKUP_RESTORE = "backup_restore_settings"
    const val THEME_CUSTOMIZATION = "theme_customization_settings"
    const val PLAYER_CUSTOMIZATION = "player_customization_settings"
    const val MINIPLAYER_CUSTOMIZATION = "miniplayer_customization_settings"
    const val EQUALIZER = "equalizer_settings"
    const val SLEEP_TIMER = "sleep_timer_settings"
    const val CRASH_LOG_HISTORY = "crash_log_history_settings"
    const val QUEUE = "queue_settings"
    const val PLAYBACK = "playback_settings"
    const val LYRICS = "lyrics_settings"
    const val WIDGET = "widget_settings"
    const val HOME_SCREEN = "home_screen_settings"
    const val GESTURES = "gestures_settings"
    const val RHYTHM_STATS = "rhythm_stats"
    const val EXPRESSIVE_SHAPES = "expressive_shapes_settings"
    const val LIBRARY_SETTINGS = "library_settings"
    const val RHYTHM_GUARD = "rhythm_guard_settings"
    @Deprecated("Use RHYTHM_GUARD")
    const val RHYTHM_AURA = RHYTHM_GUARD
    const val GO_SETTINGS = "go_settings"
    const val ACCOUNT_SETTINGS = "custom_api_account_settings"
    const val PURCHASES_VOUCHERS = "custom_api_purchases_vouchers"
    const val BLOCKED_SONGS = "custom_api_blocked_songs"
    const val BATTERY_SAVER = "battery_saver_settings"
    const val REPLAY_GAIN = "replay_gain_settings"
    const val CROSSFADE = "crossfade_settings"
    const val NATIVE_CAPABILITIES = "tuner_native_capabilities_settings"
    const val EXTERNAL_CAPABILITIES = "tuner_external_capabilities_settings"
    const val DECODER_EXTENSIONS = "tuner_decoder_extensions_settings"
    const val DEVICE_CAPABILITIES = NATIVE_CAPABILITIES
    const val AUDIO_CAPABILITIES = EXTERNAL_CAPABILITIES
    const val AUDIO_ENGINE = EXTERNAL_CAPABILITIES
    const val FALLBACK_ENGINES = DECODER_EXTENSIONS
}

data class SettingItem(
    val icon: MaterialSymbolIcon? = null,
    val title: String,
    val description: String? = null,
    val onClick: (() -> Unit)? = null,
    val toggleState: Boolean? = null,
    val onToggleChange: ((Boolean) -> Unit)? = null,
    val data: Any? = null,
    val enabled: Boolean = true,
    val palette: SettingsBadgePalette? = null
)

data class SettingGroup(
    val title: String,
    val items: List<SettingItem>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onNavigateTo: (String) -> Unit, // Add navigation callback
    scrollState: LazyListState? = null, // Optional scroll state parameter
    isTablet: Boolean = false // Whether this is displayed on a tablet
) {
    val hapticFeedback = LocalHapticFeedback.current
    val context = LocalContext.current
    val appSettings = AppSettings.getInstance(context)
    
    // Collect states for toggles
    val updatesEnabled by appSettings.updatesEnabled.collectAsState()
    val hapticFeedbackEnabled by appSettings.hapticFeedbackEnabled.collectAsState()
    val defaultScreen by appSettings.defaultScreen.collectAsState()
    val showAlphabetBar by appSettings.showAlphabetBar.collectAsState()
    val showScrollToTop by appSettings.showScrollToTop.collectAsState()
    val appMode by appSettings.appMode.collectAsState()
    val rhythmGuardMode by appSettings.rhythmGuardMode.collectAsState()
    val showSettingsSuggestions by appSettings.showSettingsSuggestions.collectAsState()
    val showKeyboardOnSearchOpen by appSettings.showKeyboardOnSearchOpen.collectAsState()
    
    var showDefaultScreenDialog by remember { mutableStateOf(false) }
    var showLanguageSwitcher by remember { mutableStateOf(false) }
    var showFdroidWarningDialog by remember { mutableStateOf(false) }
    
    // Search state
    var searchQuery by remember { mutableStateOf("") }
    val searchIndex = remember(context) { buildSettingsSearchIndex(context) }
    val searchResults = remember(searchQuery, searchIndex) { 
        searchSettings(searchQuery, searchIndex) 
    }
    val isSearchActive = searchQuery.isNotEmpty()

    CollapsibleHeaderScreen(
        title = context.getString(R.string.settings_title),
        showBackButton = !isTablet,
        onBackClick = {
            if (isSearchActive) {
                searchQuery = ""
            } else {
                HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.HEAVY)
                onBackClick()
            }
        }
        ,
        headerContent = {
            // Settings search moved into header
            SettingsSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                modifier = Modifier
                    .padding(horizontal = if (isTablet) 32.dp else 24.dp)
                    .padding(top = 14.dp, bottom = 8.dp)
            )
        }
    ) { modifier ->
        val settingGroups = listOf(
            // 1. Look & Feel
            SettingGroup(
                title = context.getString(R.string.settings_section_appearance),
                items = buildList {
                    add(SettingItem(RhythmIcons.Palette, context.getString(R.string.settings_theme_customization), context.getString(R.string.settings_theme_customization_desc), palette = SettingsPalettes.Purple, onClick = { onNavigateTo(SettingsRoutes.THEME_CUSTOMIZATION) }))
                    add(SettingItem(MaterialSymbolIcon("interests"), context.getString(R.string.settings_shapes), context.getString(R.string.settings_shapes_desc), palette = SettingsPalettes.Purple, onClick = { onNavigateTo(SettingsRoutes.EXPRESSIVE_SHAPES) }))
                    add(SettingItem(RhythmIcons.MusicNote, context.getString(R.string.settings_player_customization), context.getString(R.string.settings_player_customization_desc), palette = SettingsPalettes.SkyBlue, onClick = { onNavigateTo(SettingsRoutes.PLAYER_CUSTOMIZATION) }))
                    add(SettingItem(MaterialSymbolIcon("dock_to_bottom"), context.getString(R.string.settings_miniplayer_customization), context.getString(R.string.settings_miniplayer_customization_desc), palette = SettingsPalettes.Rose, onClick = { onNavigateTo(SettingsRoutes.MINIPLAYER_CUSTOMIZATION) }))
                }
            ),
            // 2. Home & Widgets - only show in LOCAL mode
            if (appMode == "LOCAL") SettingGroup(
                title = context.getString(R.string.settings_section_home_widgets),
                items = listOf(
                    SettingItem(RhythmIcons.Home, context.getString(R.string.settings_home_customization), context.getString(R.string.settings_home_customization_desc), palette = SettingsPalettes.Orange, onClick = { onNavigateTo(SettingsRoutes.HOME_SCREEN) }),
                    SettingItem(MaterialSymbolIcon("widgets"), context.getString(R.string.settings_widget), context.getString(R.string.settings_widget_desc), palette = SettingsPalettes.Cyan, onClick = { onNavigateTo(SettingsRoutes.WIDGET) })
                )
            ) else null,
            // 3. Navigation & Controls
            SettingGroup(
                title = context.getString(R.string.settings_section_user_interface),
                items = buildList {
                    // Default screen only applies to local navigation (streaming has its own start screen)
                    if (appMode == "LOCAL") {
                        add(SettingItem(
                            RhythmIcons.Home,
                            context.getString(R.string.settings_default_screen),
                            if (defaultScreen == "library") context.getString(R.string.library) else context.getString(R.string.home),
                            palette = SettingsPalettes.Amber,
                            onClick = { showDefaultScreenDialog = true }
                        ))
                    }
                    add(SettingItem(
                        RhythmIcons.Public,
                        context.getString(R.string.settings_language),
                        context.getString(R.string.settings_language_desc),
                        palette = SettingsPalettes.SkyBlue,
                        onClick = { showLanguageSwitcher = true }
                    ))
                    add(SettingItem(
                        MaterialSymbolIcon("touch_app"), 
                        context.getString(R.string.settings_haptic_feedback), 
                        context.getString(R.string.settings_haptic_feedback_desc), 
                        palette = SettingsPalettes.SkyBlue,
                        toggleState = hapticFeedbackEnabled,
                        onToggleChange = { appSettings.setHapticFeedbackEnabled(it) }
                    ))
                    add(SettingItem(
                        MaterialSymbolIcon("gesture"),
                        context.getString(R.string.settings_gestures),
                        context.getString(R.string.settings_gestures_desc),
                        palette = SettingsPalettes.Purple,
                        onClick = { onNavigateTo(SettingsRoutes.GESTURES) }
                    ))
                    add(SettingItem(
                        RhythmIcons.Search,
                        context.getString(R.string.settings_show_keyboard_on_search_open),
                        context.getString(R.string.settings_show_keyboard_on_search_open_desc),
                        palette = SettingsPalettes.SkyBlue,
                        toggleState = showKeyboardOnSearchOpen,
                        onToggleChange = { appSettings.setShowKeyboardOnSearchOpen(it) }
                    ))
                    add(SettingItem(
                        MaterialSymbolIcon("lightbulb"),
                        context.getString(R.string.settings_suggestions),
                        context.getString(R.string.settings_suggestions_desc),
                        palette = SettingsPalettes.Amber,
                        toggleState = showSettingsSuggestions,
                        onToggleChange = { appSettings.setShowSettingsSuggestions(it) }
                    ))
                }
            ),
            // 4. Queue & Playback
            SettingGroup(
                title = context.getString(R.string.settings_section_queue_playback),
                items = buildList {
                    add(SettingItem(RhythmIcons.Queue, context.getString(R.string.settings_queue), context.getString(R.string.settings_queue_desc), palette = SettingsPalettes.SkyBlue, onClick = { onNavigateTo(SettingsRoutes.QUEUE) }))
                    add(SettingItem(RhythmIcons.Play, context.getString(R.string.settings_playback), context.getString(R.string.settings_playback_desc), palette = SettingsPalettes.Emerald, onClick = { onNavigateTo(SettingsRoutes.PLAYBACK) }))
                    // Sleep Timer is available in both LOCAL and STREAMING modes
                    add(SettingItem(RhythmIcons.AccessTime, context.getString(R.string.sleep_timer), context.getString(R.string.sleep_timer_set_control), palette = SettingsPalettes.Orange, onClick = { onNavigateTo(SettingsRoutes.SLEEP_TIMER) }))
                }
            ),
            // 5. Audio & Lyrics
            SettingGroup(
                title = context.getString(R.string.settings_section_audio_lyrics),
                items = buildList {
                    // Equalizer is available in both LOCAL and STREAMING modes
                    add(SettingItem(RhythmIcons.Equalizer, context.getString(R.string.settings_equalizer_title), context.getString(R.string.settings_equalizer_desc), palette = SettingsPalettes.Coral, onClick = { onNavigateTo(SettingsRoutes.EQUALIZER) }))
                    add(SettingItem(
                        icon = MaterialSymbolIcon("lyrics"),
                        title = context.getString(R.string.settings_lyrics_source),
                        description = context.getString(R.string.playback_lyrics_priority_desc),
                        palette = SettingsPalettes.Cyan,
                        onClick = { onNavigateTo(SettingsRoutes.LYRICS) }
                    ))
                    add(SettingItem(
                        icon = MaterialSymbolIcon("speed"),
                        title = stringResource(R.string.performancesettingsscreen_performance),
                        description = context.getString(R.string.settings_performance_desc_optimized),
                        palette = SettingsPalettes.Lime,
                        onClick = { onNavigateTo(SettingsRoutes.BATTERY_SAVER) }
                    ))
                }
            ),
            // 6. Library & Media - only show in LOCAL mode
            if (appMode == "LOCAL") SettingGroup(
                title = context.getString(R.string.settings_section_library_content),
                items = listOf(
                    SettingItem(RhythmIcons.Folder, context.getString(R.string.settings_media_scan_title), context.getString(R.string.settings_media_scan_desc), palette = SettingsPalettes.Amber, onClick = { onNavigateTo(SettingsRoutes.MEDIA_SCAN) }),
                    SettingItem(RhythmIcons.Artist, context.getString(R.string.settings_artist_parsing), context.getString(R.string.settings_artist_parsing_desc), palette = SettingsPalettes.Rose, onClick = { onNavigateTo(SettingsRoutes.ARTIST_SEPARATORS) }),
                    SettingItem(MaterialSymbolIcon("playlist_add_check_circle"), context.getString(R.string.settings_playlists_title), context.getString(R.string.settings_playlists_desc), palette = SettingsPalettes.Coral, onClick = { onNavigateTo(SettingsRoutes.PLAYLISTS) }),
                    SettingItem(RhythmIcons.Library, context.getString(R.string.settings_library_settings), context.getString(R.string.settings_library_settings_desc), palette = SettingsPalettes.Teal, onClick = { onNavigateTo(SettingsRoutes.LIBRARY_SETTINGS) })
                )
            ) else null,
            // 6. Notifications & Services
            SettingGroup(
                title = context.getString(R.string.settings_section_notifications_services),
                items = buildList {
                    add(SettingItem(RhythmIcons.Notifications, context.getString(R.string.settings_notifications), context.getString(R.string.settings_notifications_desc), palette = SettingsPalettes.Coral, onClick = { onNavigateTo(SettingsRoutes.NOTIFICATIONS) }))
                    add(SettingItem(MaterialSymbolIcon("cloud_queue"), context.getString(R.string.streaming_service_custom_api), context.getString(R.string.streaming_service_custom_api_desc), palette = SettingsPalettes.SkyBlue, onClick = { onNavigateTo(SettingsRoutes.GO_SETTINGS) }))
                }
            ),
            // 6b. Account & Store
            SettingGroup(
                title = context.getString(R.string.custom_api_account_section),
                items = listOf(
                    SettingItem(MaterialSymbolIcon("shopping_bag"), context.getString(R.string.custom_api_purchases_vouchers_title), context.getString(R.string.custom_api_purchases_vouchers_desc), palette = SettingsPalettes.Amber, onClick = { onNavigateTo(SettingsRoutes.PURCHASES_VOUCHERS) }),
                    SettingItem(RhythmIcons.Block, context.getString(R.string.custom_api_blocked_songs_title), context.getString(R.string.custom_api_blocked_songs_desc), palette = SettingsPalettes.Rose, onClick = { onNavigateTo(SettingsRoutes.BLOCKED_SONGS) })
                )
            ),
            // 7. Data & Storage - split into shared and local-only items
            SettingGroup(
                title = context.getString(R.string.settings_section_storage_data),
                items = buildList {
                    // Listening Stats and Rhythm Guard are shared across LOCAL and STREAMING modes
                    add(SettingItem(MaterialSymbolIcon("auto_graph"), context.getString(R.string.settings_rhythm_stats), context.getString(R.string.settings_rhythm_stats_desc), palette = SettingsPalettes.Purple, onClick = { onNavigateTo(SettingsRoutes.RHYTHM_STATS) }))
                    add(SettingItem(RhythmIcons.Security, context.getString(R.string.settings_rhythm_guard), context.getString(R.string.settings_rhythm_guard_list_desc), palette = SettingsPalettes.Emerald, onClick = { onNavigateTo(SettingsRoutes.RHYTHM_GUARD) }))
                    // Cache and Backup are LOCAL-only
                    if (appMode == "LOCAL") {
                        add(SettingItem(RhythmIcons.Storage, context.getString(R.string.settings_cache_management_title), context.getString(R.string.settings_cache_management_desc), palette = SettingsPalettes.Yellow, onClick = { onNavigateTo(SettingsRoutes.CACHE_MANAGEMENT) }))
                        add(SettingItem(MaterialSymbolIcon("backup"), context.getString(R.string.settings_backup_restore_title), context.getString(R.string.settings_backup_restore_desc), palette = SettingsPalettes.Emerald, onClick = { onNavigateTo(SettingsRoutes.BACKUP_RESTORE) }))
                    }
                }
            ),
            // 8. Updates & Info
            SettingGroup(
                title = context.getString(R.string.settings_section_updates_info),
                items = listOf(
                    SettingItem(
                        RhythmIcons.Update,
                        context.getString(R.string.settings_updates_title),
                        context.getString(R.string.settings_updates_desc),
                        palette = SettingsPalettes.SkyBlue,
                        toggleState = updatesEnabled,
                        onToggleChange = { enabled ->
                            if (enabled) {
                                if (BuildConfig.FLAVOR == "fdroid") {
                                    showFdroidWarningDialog = true
                                } else {
                                    appSettings.setUpdatesEnabled(true)
                                }
                            } else {
                                appSettings.setUpdatesEnabled(false)
                            }
                        },
                        onClick = { onNavigateTo(SettingsRoutes.UPDATES) }
                    ),
                    SettingItem(RhythmIcons.Info, context.getString(R.string.settings_about_title), context.getString(R.string.settings_about_desc), palette = SettingsPalettes.Slate, onClick = { onNavigateTo(SettingsRoutes.ABOUT) })
                )
            ),
            // 9. Advanced
            SettingGroup(
                title = context.getString(R.string.settings_section_advanced),
                items = listOf(
                    SettingItem(RhythmIcons.BugReport, context.getString(R.string.settings_crash_log_history), context.getString(R.string.settings_crash_log_history_desc), palette = SettingsPalettes.Coral, onClick = { onNavigateTo(SettingsRoutes.CRASH_LOG_HISTORY) }),
                    SettingItem(MaterialSymbolIcon("science"), context.getString(R.string.settings_labs), context.getString(R.string.settings_labs_desc), palette = SettingsPalettes.Purple, onClick = { onNavigateTo(SettingsRoutes.LABS) })
                )
            )
        ).filterNotNull() // Filter out null groups (for streaming mode)

        val lazyListState = scrollState ?: rememberSaveable(
            saver = LazyListStateSaver
        ) {
            LazyListState()
        }

        // Settings search results view
        if (isSearchActive) {
            SettingsSearchResults(
                results = searchResults,
                onResultClick = { result ->
                    if (result.route != null) {
                        onNavigateTo(result.route)
                    }
                    searchQuery = "" // Clear search when item clicked
                },
                modifier = modifier
                    .fillMaxSize()
                    .padding(horizontal = if (isTablet) 32.dp else 24.dp)
            )
        } else {
            // Main settings list
            Box(modifier = modifier.fillMaxSize()) {
                LazyColumn(
                    state = lazyListState,
                    contentPadding = PaddingValues(
                        bottom = 24.dp + LocalMiniPlayerPadding.current.calculateBottomPadding()
                    ),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = if (isTablet) 32.dp else 24.dp)
                ) {
                    if (showSettingsSuggestions) {
                        item(key = "settings_suggestions") {
                            SettingsTipsRow(
                                onNavigateTo = onNavigateTo,
                                rhythmGuardMode = rhythmGuardMode,
                                appMode = appMode,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 14.dp, bottom = 2.dp)
                            )
                        }
                    }

                    itemsIndexed(settingGroups, key = { _, group -> "setting_${group.title}" }) { index, group ->
                        Spacer(
                            modifier = Modifier.height(
                                if (index == 0 && showSettingsSuggestions) 10.dp else 28.dp
                            )
                        )

                        val materialItems = group.items.map { item ->
                            Material3SettingsItem(
                                icon = item.icon,
                                palette = item.palette,
                                title = { Text(item.title) },
                                description = item.description?.let { descriptionText ->
                                    { Text(descriptionText) }
                                },
                                trailingContent = when {
                                    item.toggleState != null && item.onClick != null -> {
                                        {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = MaterialSymbolIcon("arrow_forward_ios", filled = true),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp),
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .width(1.dp)
                                                        .height(20.dp)
                                                        .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                AnimatedSwitch(
                                                    checked = item.toggleState,
                                                    onCheckedChange = {
                                                        HapticUtils.performHapticFeedback(
                                                            context,
                                                            hapticFeedback,
                                                            HapticType.LIGHT
                                                        )
                                                        item.onToggleChange?.invoke(it)
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    item.toggleState != null -> {
                                        {
                                            AnimatedSwitch(
                                                checked = item.toggleState,
                                                onCheckedChange = {
                                                    HapticUtils.performHapticFeedback(
                                                        context,
                                                        hapticFeedback,
                                                        HapticType.LIGHT
                                                    )
                                                    item.onToggleChange?.invoke(it)
                                                }
                                            )
                                        }
                                    }

                                    item.onClick != null -> {
                                        {
                                            Icon(
                                                imageVector = MaterialSymbolIcon("arrow_forward_ios", filled = true),
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                            )
                                        }
                                    }

                                    else -> null
                                },
                                isHighlighted = false,
                                enabled = item.enabled,
                                onClick = when {
                                    item.onClick != null -> {
                                        {
                                            HapticUtils.performHapticFeedback(
                                                context,
                                                hapticFeedback,
                                                HapticType.HEAVY
                                            )
                                            item.onClick.invoke()
                                        }
                                    }

                                    item.toggleState != null && item.onToggleChange != null -> {
                                        {
                                            HapticUtils.performHapticFeedback(
                                                context,
                                                hapticFeedback,
                                                HapticType.LIGHT
                                            )
                                            item.onToggleChange.invoke(!item.toggleState)
                                        }
                                    }

                                    else -> null
                                }
                            )
                        }

                        Material3SettingsGroup(
                            title = group.title,
                            items = materialItems,
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        )
                    }
                }
            } // End of else branch for search
        } // End of Column
        
        // Default screen selection bottom sheet
        if (showDefaultScreenDialog) {
            val sheetState = rememberBottomSheetState(initialValue = SheetValue.Hidden, enabledValues = setOf(SheetValue.Hidden, SheetValue.Expanded))
            
            RhythmAdaptiveModalSheet(
                adaptiveType = SheetAdaptiveType.AUTO_DIALOG,
                onDismissRequest = { showDefaultScreenDialog = false },
                sheetState = sheetState,
                dragHandle = { 
                    BottomSheetDefaults.DragHandle(
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth()
            ) {
                StandardBottomSheetHeader(
                    title = context.getString(R.string.settings_default_screen),
                    subtitle = context.getString(R.string.settings_default_screen_desc),
                    visible = true
                )

                val scrollState = rememberScrollState()

                AdaptiveSheetScrollContainer(
                    scrollState = scrollState,
                    modifier = Modifier.fillMaxWidth()
                ) { endPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(scrollState)
                            .padding(start = 24.dp, end = 24.dp + endPadding, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Home option
                        Card(
                            onClick = {
                                HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.LIGHT)
                                appSettings.setDefaultScreen("home")
                                showDefaultScreenDialog = false
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (defaultScreen == "home") 
                                    MaterialTheme.colorScheme.primaryContainer 
                                else 
                                    MaterialTheme.colorScheme.surfaceContainerHigh
                            ),
                            shape = groupedBottomSheetItemShape(0, 2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = RhythmIcons.Home,
                                    contentDescription = null,
                                    tint = if (defaultScreen == "home") 
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else 
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(if (defaultScreen == "home") 30.dp else 26.dp)
                                )
                                
                                Spacer(modifier = Modifier.width(16.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = context.getString(R.string.common_home),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (defaultScreen == "home") 
                                            MaterialTheme.colorScheme.onPrimaryContainer 
                                        else 
                                            MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = context.getString(R.string.settings_home_desc),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (defaultScreen == "home") 
                                            MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                        else 
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                
                                if (defaultScreen == "home") {
                                    Icon(
                                        imageVector = RhythmIcons.CheckCircle,
                                        contentDescription = stringResource(R.string.streaming_selected),
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                        
                        // Library option
                        Card(
                            onClick = {
                                HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.LIGHT)
                                appSettings.setDefaultScreen("library")
                                showDefaultScreenDialog = false
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (defaultScreen == "library") 
                                    MaterialTheme.colorScheme.primaryContainer 
                                else 
                                    MaterialTheme.colorScheme.surfaceContainerHigh
                            ),
                            shape = groupedBottomSheetItemShape(1, 2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = RhythmIcons.Library,
                                    contentDescription = null,
                                    tint = if (defaultScreen == "library") 
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else 
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(if (defaultScreen == "library") 30.dp else 26.dp)
                                )
                                
                                Spacer(modifier = Modifier.width(16.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = context.getString(R.string.common_library),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (defaultScreen == "library") 
                                            MaterialTheme.colorScheme.onPrimaryContainer 
                                        else 
                                            MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = context.getString(R.string.settings_library_desc),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (defaultScreen == "library") 
                                            MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                        else 
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                
                                if (defaultScreen == "library") {
                                    Icon(
                                        imageVector = RhythmIcons.CheckCircle,
                                        contentDescription = stringResource(R.string.streaming_selected),
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if (showLanguageSwitcher) {
            LanguageSwitcherBottomSheet(
                onDismiss = { showLanguageSwitcher = false }
            )
        }
        
        if (showFdroidWarningDialog) {
            FdroidUpdateWarningDialog(
                onDismiss = { showFdroidWarningDialog = false },
                onConfirm = {
                    appSettings.setUpdatesEnabled(true)
                }
            )
        }
        
        // App Mode selection dialog
    }
}

@Composable
fun SettingRow(item: SettingItem) {
    val hapticFeedback = LocalHapticFeedback.current
    val context = LocalContext.current
    val appSettings = AppSettings.getInstance(context)
    val hapticFeedbackEnabled by appSettings.hapticFeedbackEnabled.collectAsState()
    
    // Animation states
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "setting_scale"
    )
    
    val iconBackgroundColor by animateColorAsState(
        targetValue = when {
            item.toggleState == true -> MaterialTheme.colorScheme.primaryContainer
            isPressed -> MaterialTheme.colorScheme.secondaryContainer
            else -> MaterialTheme.colorScheme.surfaceContainerHighest
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "icon_bg_color"
    )
    
    val iconTintColor by animateColorAsState(
        targetValue = when {
            item.toggleState == true -> MaterialTheme.colorScheme.onPrimaryContainer
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "icon_tint_color"
    )
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon container with expressive design
        item.icon?.let { icon ->
            Surface(
                modifier = Modifier.size(40.dp),
                shape = RoundedCornerShape(24.dp),
                color = iconBackgroundColor,
                tonalElevation = if (item.toggleState == true) 2.dp else 0.dp
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = item.title,
                        modifier = Modifier.size(24.dp),
                        tint = iconTintColor
                    )
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
        }
        
        Column(
            modifier = Modifier
                .weight(1f)
                .then(
                    if (item.onClick != null && item.toggleState == null) {
                        Modifier.clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {
                                isPressed = true
                                HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.HEAVY)
                                item.onClick()
                            }
                        )
                    } else if (item.onClick != null && item.toggleState != null) {
                        Modifier.clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {
                                isPressed = true
                                HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.HEAVY)
                                item.onClick()
                            }
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            item.description?.let {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = MaterialTheme.typography.bodyMedium.lineHeight
                )
            }
        }

        if (item.toggleState != null && item.onClick != null) {
            Icon(
                imageVector = MaterialSymbolIcon("arrow_forward_ios", filled = true),
                contentDescription = stringResource(R.string.cd_navigate),
                modifier = Modifier
                    .size(18.dp)
                    .padding(end = 8.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            AnimatedSwitch(
                checked = item.toggleState,
                onCheckedChange = {
                    HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.LIGHT)
                    item.onToggleChange?.invoke(it)
                }
            )
        } else if (item.toggleState != null) {
            AnimatedSwitch(
                checked = item.toggleState,
                onCheckedChange = {
                    HapticUtils.performHapticFeedback(context, hapticFeedback, HapticType.LIGHT)
                    item.onToggleChange?.invoke(it)
                }
            )
        } else if (item.onClick != null) {
            Icon(
                imageVector = MaterialSymbolIcon("arrow_forward_ios", filled = true),
                contentDescription = stringResource(R.string.cd_navigate),
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    RhythmTheme {
        SettingsScreen(onBackClick = {}, onNavigateTo = {})
    }
}

// Wrapper function for navigation
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreenWrapper(
    onBack: () -> Unit,
    appSettings: chromahub.rhythm.app.shared.data.model.AppSettings,
    navController: androidx.navigation.NavController,
    musicViewModel: MusicViewModel
) {
    val isTablet = windowScreenWidthDp() >= 600
    val isLandscapeTablet = isTablet && windowScreenWidthDp() > windowScreenHeightDp()

    var routeStack by rememberSaveable { mutableStateOf(emptyList<String>()) }
    var showSleepTimerBottomSheet by rememberSaveable { mutableStateOf(false) }
    val currentSong by musicViewModel.currentSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val appMode by appSettings.appMode.collectAsState()

    // Hoist the main settings scroll state to persist across navigation
    val mainSettingsScrollState = rememberSaveable(
        saver = LazyListStateSaver
    ) {
        LazyListState()
    }

    // Handle back navigation
    val handleBack: () -> Unit = {
        if (routeStack.isNotEmpty()) {
            routeStack = routeStack.dropLast(1)
        } else {
            onBack()
        }
    }

    // Consume any initial subroute requested by external callers (e.g., open settings -> specific pane)
    LaunchedEffect(Unit) {
        val pending = appSettings.consumeInitialSettingsSubroute()
        if (!pending.isNullOrBlank()) {
            routeStack = listOf(pending)
        }
    }

    // Handle system back gestures when in subsettings
    BackHandler(enabled = routeStack.isNotEmpty()) {
        handleBack()
    }

    val onNavigateToSubsetting: (String) -> Unit = { route: String ->
        if (route == SettingsRoutes.RHYTHM_STATS) {
            val localStatsRoute = Screen.RhythmStats.route
            val streamingStatsRoute = "streaming_rhythm_stats"
            when {
                navController.graph.findNode(streamingStatsRoute) != null -> navController.navigate(streamingStatsRoute)
                navController.graph.findNode(localStatsRoute) != null -> navController.navigate(localStatsRoute)
                appMode == "STREAMING" -> {
                    appSettings.setInitialStreamingRoute(streamingStatsRoute)
                    if (!navController.popBackStack()) {
                        safeNavigateToMain(navController)
                    }
                }
                else -> {
                    appSettings.setInitialStreamingRoute(localStatsRoute)
                    if (!navController.popBackStack()) {
                        safeNavigateToMain(navController)
                    }
                }
            }
        } else if (route == SettingsRoutes.EQUALIZER) {
            navController.navigate(Screen.Equalizer.route)
        } else if (route == SettingsRoutes.SLEEP_TIMER) {
            showSleepTimerBottomSheet = true
        } else {
            if (routeStack.lastOrNull() != route) {
                routeStack = routeStack + route
            }
        }
    }

    if (isLandscapeTablet) {
        // Tablet layout: Master-detail with settings always visible on left
        Row(modifier = Modifier.fillMaxSize()) {
            // Master pane - always visible settings list
            Surface(
                modifier = Modifier
                    .weight(0.35f)
                    .fillMaxHeight(),
            ) {
                SettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = { route ->
                        if (route == SettingsRoutes.RHYTHM_STATS || route == SettingsRoutes.EQUALIZER || route == SettingsRoutes.SLEEP_TIMER) {
                            onNavigateToSubsetting(route)
                        } else {
                            routeStack = listOf(route)
                        }
                    },
                    scrollState = mainSettingsScrollState,
                    isTablet = true
                )
            }

            // Divider

            // Detail pane - subsettings or placeholder
            Surface(
                modifier = Modifier
                    .weight(0.65f)
                    .fillMaxHeight(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp
            ) {
                AnimatedContent(
                    targetState = routeStack,
                    transitionSpec = {
                        val isBacking = targetState.size < initialState.size
                        if (!isBacking && targetState.isNotEmpty()) {
                            slideInHorizontally(
                                initialOffsetX = { it },
                                animationSpec = tween(
                                    durationMillis = 400,
                                    easing = androidx.compose.animation.core.EaseOutCubic
                                )
                            ) + fadeIn(
                                animationSpec = tween(
                                    durationMillis = 350,
                                    delayMillis = 50
                                )
                            ) togetherWith
                            slideOutHorizontally(
                                targetOffsetX = { -it / 4 },
                                animationSpec = tween(
                                    durationMillis = 350,
                                    easing = androidx.compose.animation.core.EaseInCubic
                                )
                            ) + fadeOut(
                                animationSpec = tween(durationMillis = 250)
                            )
                        } else {
                            slideInHorizontally(
                                initialOffsetX = { -it / 4 },
                                animationSpec = tween(
                                    durationMillis = 400,
                                    easing = androidx.compose.animation.core.EaseOutCubic
                                )
                            ) + fadeIn(
                                animationSpec = tween(
                                    durationMillis = 350,
                                    delayMillis = 50
                                )
                            ) togetherWith
                            slideOutHorizontally(
                                targetOffsetX = { it },
                                animationSpec = tween(
                                    durationMillis = 350,
                                    easing = androidx.compose.animation.core.EaseInCubic
                                )
                            ) + fadeOut(
                                animationSpec = tween(durationMillis = 250)
                            )
                        }
                    },
                    label = "tablet_detail_navigation",
                    contentKey = { it.lastOrNull() ?: "placeholder" }
                ) { stack ->
                    val route = stack.lastOrNull()
                    when (route) {
                        SettingsRoutes.NOTIFICATIONS -> NotificationsSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.PLAYLISTS -> PlaylistsSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.DEFAULT_PLAYLISTS -> DefaultPlaylistsSettingsScreen(
                            onBackClick = handleBack
                        )
                        SettingsRoutes.MEDIA_SCAN -> MediaScanSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.ARTIST_SEPARATORS -> ArtistSeparatorsSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.ABOUT -> chromahub.rhythm.app.shared.presentation.screens.settings.AboutScreen(
                            onBackClick = handleBack,
                            onNavigateToUpdates = { onNavigateToSubsetting(SettingsRoutes.UPDATES) },
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.NATIVE_CAPABILITIES, SettingsRoutes.DEVICE_CAPABILITIES -> NativeCapabilitiesSettingsScreen(
                            onBackClick = handleBack
                        )
                        SettingsRoutes.EXTERNAL_CAPABILITIES, SettingsRoutes.AUDIO_CAPABILITIES, SettingsRoutes.AUDIO_ENGINE -> ExternalCapabilitiesSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.DECODER_EXTENSIONS, SettingsRoutes.FALLBACK_ENGINES -> DecoderExtensionsSettingsScreen(
                            onBackClick = handleBack
                        )
                        SettingsRoutes.UPDATES -> UpdatesSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.LABS, SettingsRoutes.EXPERIMENTAL_FEATURES -> LabsSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting,
                            onNavigateToGoSettings = { onNavigateToSubsetting(SettingsRoutes.GO_SETTINGS) }
                        )
                        SettingsRoutes.GO_SETTINGS -> chromahub.rhythm.app.features.streaming.presentation.screens.GoSettingsScreen(
                            onBackClick = handleBack,
                            onConfigureCurrentProvider = { _ ->
                                appSettings.setInitialStreamingRoute("personal_profile")
                                appSettings.setAppMode("STREAMING")
                                if (!navController.popBackStack()) {
                                    safeNavigateToMain(navController)
                                }
                            },
                            onOpenAccountSettings = {
                                appSettings.setInitialStreamingRoute("personal_profile")
                                appSettings.setAppMode("STREAMING")
                                if (!navController.popBackStack()) {
                                    safeNavigateToMain(navController)
                                }
                            },
                            onOpenPurchases = { onNavigateToSubsetting(SettingsRoutes.PURCHASES_VOUCHERS) },
                            onOpenBlockedSongs = { onNavigateToSubsetting(SettingsRoutes.BLOCKED_SONGS) }
                        )
                        SettingsRoutes.ACCOUNT_SETTINGS -> {
                            val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                            chromahub.rhythm.app.features.streaming.presentation.screens.AccountAndCloudSettingsScreen(
                                viewModel = streamingVm,
                                onBackClick = handleBack
                            )
                        }
                        SettingsRoutes.PURCHASES_VOUCHERS -> {
                            val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                            chromahub.rhythm.app.features.streaming.presentation.screens.PurchasesAndVouchersScreen(
                                viewModel = streamingVm,
                                onBackClick = handleBack
                            )
                        }
                        SettingsRoutes.BLOCKED_SONGS -> {
                            val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                            chromahub.rhythm.app.features.streaming.presentation.screens.BlockedSongsScreen(
                                viewModel = streamingVm,
                                onBackClick = handleBack
                            )
                        }
                        SettingsRoutes.API_MANAGEMENT -> {
                            LaunchedEffect(Unit) { handleBack() }
                        }
                        SettingsRoutes.CACHE_MANAGEMENT -> CacheManagementSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.BACKUP_RESTORE -> BackupRestoreSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.THEME_CUSTOMIZATION -> ThemeCustomizationSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.PLAYER_CUSTOMIZATION -> PlayerCustomizationSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.MINIPLAYER_CUSTOMIZATION -> MiniPlayerCustomizationSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.CRASH_LOG_HISTORY -> CrashLogHistorySettingsScreen(onBackClick = handleBack, appSettings = appSettings)
                        SettingsRoutes.QUEUE -> QueueSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.PLAYBACK -> PlaybackSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.REPLAY_GAIN -> ReplayGainSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.CROSSFADE -> CrossfadeSettingsScreen(
                            onBackClick = handleBack,
                            onNavigateTo = onNavigateToSubsetting
                        )
                        SettingsRoutes.LYRICS -> LyricsSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.WIDGET -> WidgetSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.HOME_SCREEN -> HomeScreenCustomizationSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.GESTURES -> GesturesSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.EXPRESSIVE_SHAPES -> ExpressiveShapesSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.LIBRARY_SETTINGS -> LibrarySettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.RHYTHM_GUARD -> RhythmGuardSettingsScreen(onBackClick = handleBack)
                        SettingsRoutes.BATTERY_SAVER -> PerformanceSettingsScreen(onBackClick = handleBack)
                        else -> PlaceholderSettingsScreen()
                    }
                }
            }
        }
    } else {
        // Phone layout: Traditional navigation with AnimatedContent
        AnimatedContent(
            targetState = routeStack,
            transitionSpec = {
                val isBacking = targetState.size < initialState.size
                if (!isBacking && targetState.isNotEmpty()) {
                    slideInHorizontally(
                        initialOffsetX = { it },
                        animationSpec = tween(
                            durationMillis = 400,
                            easing = androidx.compose.animation.core.EaseOutCubic
                        )
                    ) + fadeIn(
                        animationSpec = tween(
                            durationMillis = 350,
                            delayMillis = 50
                        )
                    ) + scaleIn(
                        initialScale = 0.92f,
                        animationSpec = tween(
                            durationMillis = 400,
                            easing = androidx.compose.animation.core.EaseOutCubic
                        )
                    ) togetherWith
                    slideOutHorizontally(
                        targetOffsetX = { -it / 4 },
                        animationSpec = tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.EaseInCubic
                        )
                    ) + fadeOut(
                        animationSpec = tween(durationMillis = 250)
                    ) + scaleOut(
                        targetScale = 0.95f,
                        animationSpec = tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.EaseInCubic
                        )
                    )
                } else {
                    slideInHorizontally(
                        initialOffsetX = { -it / 4 },
                        animationSpec = tween(
                            durationMillis = 400,
                            easing = androidx.compose.animation.core.EaseOutCubic
                        )
                    ) + fadeIn(
                        animationSpec = tween(
                            durationMillis = 350,
                            delayMillis = 50
                        )
                    ) + scaleIn(
                        initialScale = 0.95f,
                        animationSpec = tween(
                            durationMillis = 400,
                            easing = androidx.compose.animation.core.EaseOutCubic
                        )
                    ) togetherWith
                    slideOutHorizontally(
                        targetOffsetX = { it },
                        animationSpec = tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.EaseInCubic
                        )
                    ) + fadeOut(
                        animationSpec = tween(durationMillis = 250)
                    ) + scaleOut(
                        targetScale = 0.92f,
                        animationSpec = tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.EaseInCubic
                        )
                    )
                }
            },
            label = "settings_navigation",
            contentKey = { it.lastOrNull() ?: "main_settings" }
        ) { stack ->
            val route = stack.lastOrNull()
            when (route) {
                SettingsRoutes.NOTIFICATIONS -> NotificationsSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.PLAYLISTS -> PlaylistsSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.DEFAULT_PLAYLISTS -> DefaultPlaylistsSettingsScreen(
                    onBackClick = handleBack
                )
                SettingsRoutes.MEDIA_SCAN -> MediaScanSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.ARTIST_SEPARATORS -> ArtistSeparatorsSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.ABOUT -> chromahub.rhythm.app.shared.presentation.screens.settings.AboutScreen(
                    onBackClick = handleBack,
                    onNavigateToUpdates = { onNavigateToSubsetting(SettingsRoutes.UPDATES) },
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.NATIVE_CAPABILITIES, SettingsRoutes.DEVICE_CAPABILITIES -> NativeCapabilitiesSettingsScreen(
                    onBackClick = handleBack
                )
                SettingsRoutes.EXTERNAL_CAPABILITIES, SettingsRoutes.AUDIO_CAPABILITIES, SettingsRoutes.AUDIO_ENGINE -> ExternalCapabilitiesSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.DECODER_EXTENSIONS, SettingsRoutes.FALLBACK_ENGINES -> DecoderExtensionsSettingsScreen(
                    onBackClick = handleBack
                )
                SettingsRoutes.UPDATES -> UpdatesSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.LABS, SettingsRoutes.EXPERIMENTAL_FEATURES -> LabsSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting,
                    onNavigateToGoSettings = { onNavigateToSubsetting(SettingsRoutes.GO_SETTINGS) }
                )
                SettingsRoutes.GO_SETTINGS -> chromahub.rhythm.app.features.streaming.presentation.screens.GoSettingsScreen(
                    onBackClick = handleBack,
                    onConfigureCurrentProvider = { _ ->
                        appSettings.setInitialStreamingRoute("personal_profile")
                        appSettings.setAppMode("STREAMING")
                        if (!navController.popBackStack()) {
                            safeNavigateToMain(navController)
                        }
                    },
                    onOpenAccountSettings = {
                        appSettings.setInitialStreamingRoute("personal_profile")
                        appSettings.setAppMode("STREAMING")
                        if (!navController.popBackStack()) {
                            safeNavigateToMain(navController)
                        }
                    },
                    onOpenPurchases = { onNavigateToSubsetting(SettingsRoutes.PURCHASES_VOUCHERS) },
                    onOpenBlockedSongs = { onNavigateToSubsetting(SettingsRoutes.BLOCKED_SONGS) }
                )
                SettingsRoutes.ACCOUNT_SETTINGS -> {
                    val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                    chromahub.rhythm.app.features.streaming.presentation.screens.AccountAndCloudSettingsScreen(
                        viewModel = streamingVm,
                        onBackClick = handleBack
                    )
                }
                SettingsRoutes.PURCHASES_VOUCHERS -> {
                    val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                    chromahub.rhythm.app.features.streaming.presentation.screens.PurchasesAndVouchersScreen(
                        viewModel = streamingVm,
                        onBackClick = handleBack
                    )
                }
                SettingsRoutes.BLOCKED_SONGS -> {
                    val streamingVm: chromahub.rhythm.app.features.streaming.presentation.viewmodel.StreamingMusicViewModel = viewModel()
                    chromahub.rhythm.app.features.streaming.presentation.screens.BlockedSongsScreen(
                        viewModel = streamingVm,
                        onBackClick = handleBack
                    )
                }
                SettingsRoutes.API_MANAGEMENT -> {
                    LaunchedEffect(Unit) { handleBack() }
                }
                SettingsRoutes.CACHE_MANAGEMENT -> CacheManagementSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.BACKUP_RESTORE -> BackupRestoreSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.THEME_CUSTOMIZATION -> ThemeCustomizationSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.PLAYER_CUSTOMIZATION -> PlayerCustomizationSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.MINIPLAYER_CUSTOMIZATION -> MiniPlayerCustomizationSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.CRASH_LOG_HISTORY -> CrashLogHistorySettingsScreen(onBackClick = handleBack, appSettings = appSettings)
                SettingsRoutes.QUEUE -> QueueSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.PLAYBACK -> PlaybackSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.REPLAY_GAIN -> ReplayGainSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.CROSSFADE -> CrossfadeSettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting
                )
                SettingsRoutes.LYRICS -> LyricsSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.WIDGET -> WidgetSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.HOME_SCREEN -> HomeScreenCustomizationSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.GESTURES -> GesturesSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.EXPRESSIVE_SHAPES -> ExpressiveShapesSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.LIBRARY_SETTINGS -> LibrarySettingsScreen(onBackClick = handleBack)
                SettingsRoutes.RHYTHM_GUARD -> RhythmGuardSettingsScreen(onBackClick = handleBack)
                SettingsRoutes.BATTERY_SAVER -> PerformanceSettingsScreen(onBackClick = handleBack)
                else -> SettingsScreen(
                    onBackClick = handleBack,
                    onNavigateTo = onNavigateToSubsetting,
                    scrollState = mainSettingsScrollState
                )
            }
        }
    }

    if (showSleepTimerBottomSheet) {
        SleepTimerBottomSheetNew(
            onDismiss = { showSleepTimerBottomSheet = false },
            currentSong = currentSong,
            isPlaying = isPlaying,
            musicViewModel = musicViewModel
        )
    }
}

private fun safeNavigateToMain(navController: androidx.navigation.NavController) {
    if (navController.graph.findNode("main") != null) {
        navController.navigate("main") { launchSingleTop = true }
    } else {
        val startDest = navController.graph.startDestinationRoute
        if (startDest != null) {
            navController.navigate(startDest) {
                popUpTo(startDest) { inclusive = true }
                launchSingleTop = true
            }
        }
    }
}

@Composable
fun AnimatedSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    TunerAnimatedSwitch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier
    )
}

data class SettingsTipData(
    val icon: MaterialSymbolIcon,
    val title: String,
    val text: String,
    val route: String? = null,
    val isPrimary: Boolean = false,
    val riskLevel: RhythmGuardRiskLevel? = null,
    val fillProgress: Float? = null
)

@Composable
fun SettingsTipsRow(
    onNavigateTo: (String) -> Unit,
    rhythmGuardMode: String,
    appMode: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Playback stats
    var todayExposureMinutes by remember { mutableIntStateOf(0) }
    var currentRiskLevel by remember { mutableStateOf(RhythmGuardRiskLevel.LOW) }
    
    val appSettings = remember { chromahub.rhythm.app.shared.data.model.AppSettings.getInstance(context) }
    val limitMinutes by appSettings.rhythmGuardAlertThresholdMinutes.collectAsState()
    val manualVolumeFloat by appSettings.rhythmGuardManualVolumeThreshold.collectAsState()
    val autoBackupEnabled by appSettings.autoBackupEnabled.collectAsState()
    val updatesEnabled by appSettings.updatesEnabled.collectAsState()
    val miniPlayerShowProgress by appSettings.miniPlayerShowProgress.collectAsState()
    val playerShowSeekButtons by appSettings.playerShowSeekButtons.collectAsState()
    val gesturePlayerSwipeTracks by appSettings.gesturePlayerSwipeTracks.collectAsState()

    LaunchedEffect(limitMinutes, manualVolumeFloat) {
        val statsRepo = chromahub.rhythm.app.shared.data.repository.PlaybackStatsRepository.getInstance(context)
        val audioManager = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
        
        while (true) {
            val stats = statsRepo.loadSummary(chromahub.rhythm.app.shared.data.repository.StatsTimeRange.TODAY)
            todayExposureMinutes = (stats.totalDurationMs / 60000).toInt()
            
            val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            val currentVol = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
            val currentVolumePercent = if (maxVol > 0) ((currentVol.toFloat() / maxVol) * 100).toInt() else 0
            
            val safeLimit = if (limitMinutes > 0) limitMinutes else 90
            val safeThreshold = (manualVolumeFloat * 100).toInt().coerceAtLeast(1)
            
            currentRiskLevel = chromahub.rhythm.app.shared.presentation.navigation.rhythmGuardResolveRiskLevel(
                currentVolumePercent = currentVolumePercent, 
                safeThresholdPercent = safeThreshold,
                exposureMinutes = todayExposureMinutes,
                exposureLimitMinutes = safeLimit
            )
            kotlinx.coroutines.delay(2000)
        }
    }
    
    // Generate a fixed seed when the view enters to keep shuffle stable during recompositions
    val shuffleSeed = rememberSaveable { kotlin.random.Random.nextInt() }
    
    val tips = remember(
        rhythmGuardMode,
        appMode,
        todayExposureMinutes,
        currentRiskLevel,
        autoBackupEnabled,
        updatesEnabled,
        miniPlayerShowProgress,
        playerShowSeekButtons,
        gesturePlayerSwipeTracks
    ) {
        val random = kotlin.random.Random(shuffleSeed)
        val isLocalMode = appMode == "LOCAL"
        val hourOfDay = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val dayMomentLabel = when (hourOfDay) {
            in 5..11 -> context.getString(R.string.moment_morning)
            in 12..16 -> context.getString(R.string.moment_afternoon)
            in 17..21 -> context.getString(R.string.moment_evening)
            else -> context.getString(R.string.moment_night)
        }
        val listeningPulseLabel = when {
            todayExposureMinutes < 20 -> context.getString(R.string.pulse_fresh)
            todayExposureMinutes < 60 -> context.getString(R.string.pulse_steady)
            todayExposureMinutes < 120 -> context.getString(R.string.pulse_heavy)
            else -> context.getString(R.string.pulse_marathon)
        }

        buildList {
            if (isLocalMode) {
                val desc = when (rhythmGuardMode) {
                    "OFF" -> "${context.getString(R.string.settings_tip_rhythm_guard_off)} ${listeningPulseLabel.lowercase()} ${dayMomentLabel}."
                    "MANUAL" -> "${context.getString(R.string.settings_tip_rhythm_guard_manual)} ${todayExposureMinutes} min played today."
                    else -> "${context.getString(R.string.settings_tip_rhythm_guard_auto)} ${todayExposureMinutes} min tracked ${dayMomentLabel}."
                }
                
                val progress = (todayExposureMinutes.toFloat() / 90f).coerceIn(0.05f, 1f)

                add(
                    SettingsTipData(
                        icon = RhythmIcons.Security,
                        title = context.getString(R.string.settings_rhythm_guard),
                        text = desc,
                        route = SettingsRoutes.RHYTHM_GUARD,
                        isPrimary = true,
                        riskLevel = if (rhythmGuardMode == "OFF") null else currentRiskLevel,
                        fillProgress = if (rhythmGuardMode == "OFF") null else progress
                    )
                )
            }
            val themeDescs = listOf(
                context.getString(R.string.settings_tip_theme),
                context.getString(R.string.settings_tip_theme_desc_1),
                context.getString(R.string.settings_tip_theme_desc_2)
            )
            add(
                SettingsTipData(
                    icon = RhythmIcons.Palette,
                    title = context.getString(R.string.settingsscreen_personalization),
                    text = themeDescs.random(random),
                    route = SettingsRoutes.THEME_CUSTOMIZATION
                )
            )
            val gesturesDescs = listOf(
                context.getString(R.string.settings_tip_gestures),
                context.getString(R.string.settings_tip_gestures_swipe),
                context.getString(R.string.settings_tip_gestures_artwork)
            )
            add(
                SettingsTipData(
                    icon = MaterialSymbolIcon("gesture"),
                    title = context.getString(R.string.settings_gestures),
                    text = gesturesDescs.random(random),
                    route = SettingsRoutes.GESTURES
                )
            )
            if (isLocalMode) {
                val descs = listOf(
                    context.getString(R.string.settings_tip_media_scan),
                    context.getString(R.string.settings_tip_media_scan_desc_1),
                    context.getString(R.string.settings_tip_media_scan_desc_2)
                )
                add(
                    SettingsTipData(
                        icon = RhythmIcons.Folder,
                        title = context.getString(R.string.settingsscreen_library_focus),
                        text = descs.random(random),
                        route = SettingsRoutes.MEDIA_SCAN
                    )
                )
            }
            if (isLocalMode) {
                val descs = listOf(
                    context.getString(R.string.settings_tip_sleep_timer_desc_1),
                    context.getString(R.string.settings_tip_sleep_timer_desc_2)
                )
                add(
                    SettingsTipData(
                        icon = RhythmIcons.AccessTime,
                        title = context.getString(R.string.settings_sleep_timer_search),
                        text = descs.random(random),
                        route = SettingsRoutes.SLEEP_TIMER
                    )
                )
            }
            if (isLocalMode) {
                val descs = listOf(
                    context.getString(R.string.settings_tip_equalizer_desc_1),
                    context.getString(R.string.settings_tip_equalizer_desc_2)
                )
                add(
                    SettingsTipData(
                        icon = RhythmIcons.Equalizer,
                        title = context.getString(R.string.settingsscreen_audio_equalizer),
                        text = descs.random(random),
                        route = SettingsRoutes.EQUALIZER
                    )
                )
            }
            if (isLocalMode) {
                val descs = if (autoBackupEnabled) {
                    listOf(
                        context.getString(R.string.settings_tip_backup_active_desc_1),
                        context.getString(R.string.settings_tip_backup_active_desc_2)
                    )
                } else {
                    listOf(
                        context.getString(R.string.settings_tip_backup_inactive_desc_1),
                        context.getString(R.string.settings_tip_backup_inactive_desc_2)
                    )
                }
                add(
                    SettingsTipData(
                        icon = MaterialSymbolIcon("backup"),
                        title = context.getString(R.string.settings_backup_restore),
                        text = descs.random(random),
                        route = SettingsRoutes.BACKUP_RESTORE
                    )
                )
            }
            val updatesDescs = if (updatesEnabled) {
                listOf(
                    context.getString(R.string.settings_tip_updates_active_desc_1),
                    context.getString(R.string.settings_tip_updates_active_desc_2)
                )
            } else {
                listOf(
                    context.getString(R.string.settings_tip_updates_inactive_desc_1),
                    context.getString(R.string.settings_tip_updates_inactive_desc_2)
                )
            }
            add(
                SettingsTipData(
                    icon = RhythmIcons.Update,
                    title = context.getString(R.string.cd_app_updates),
                    text = updatesDescs.random(random),
                    route = SettingsRoutes.UPDATES
                )
            )
            val queueDescs = if (gesturePlayerSwipeTracks) {
                listOf(
                    context.getString(R.string.settings_tip_queue_active_desc_1),
                    context.getString(R.string.settings_tip_queue_active_desc_2)
                )
            } else {
                listOf(
                    context.getString(R.string.settings_tip_queue_inactive_desc_1),
                    context.getString(R.string.settings_tip_queue_inactive_desc_2)
                )
            }
            add(
                SettingsTipData(
                    icon = RhythmIcons.Queue,
                    title = context.getString(R.string.settings_queue_title),
                    text = queueDescs.random(random),
                    route = SettingsRoutes.QUEUE
                )
            )
            val controlsDescs = if (playerShowSeekButtons) {
                listOf(
                    context.getString(R.string.settings_tip_controls_active_desc_1),
                    context.getString(R.string.settings_tip_controls_active_desc_2)
                )
            } else {
                listOf(
                    context.getString(R.string.settings_tip_controls_inactive_desc_1),
                    context.getString(R.string.settings_tip_controls_inactive_desc_2)
                )
            }
            add(
                SettingsTipData(
                    icon = RhythmIcons.MusicNote,
                    title = context.getString(R.string.settings_shapes_player_controls),
                    text = controlsDescs.random(random),
                    route = SettingsRoutes.PLAYER_CUSTOMIZATION
                )
            )
            val miniplayerDescs = if (miniPlayerShowProgress) {
                listOf(
                    context.getString(R.string.settings_tip_miniplayer_active_desc_1),
                    context.getString(R.string.settings_tip_miniplayer_active_desc_2)
                )
            } else {
                listOf(
                    context.getString(R.string.settings_tip_miniplayer_inactive_desc_1),
                    context.getString(R.string.settings_tip_miniplayer_inactive_desc_2)
                )
            }
            add(
                SettingsTipData(
                    icon = MaterialSymbolIcon("dock_to_bottom"),
                    title = context.getString(R.string.settings_shapes_mini_player),
                    text = miniplayerDescs.random(random),
                    route = SettingsRoutes.MINIPLAYER_CUSTOMIZATION
                )
            )
            if (isLocalMode) {
                add(
                    SettingsTipData(
                        icon = RhythmIcons.Library,
                        title = context.getString(R.string.settingsscreen_library_settings),
                        text = context.getString(R.string.settings_library_settings_desc),
                        route = SettingsRoutes.LIBRARY_SETTINGS
                    )
                )
            }
        }.shuffled(random)
    }

    if (tips.isNotEmpty()) {
        SettingsTipsCarousel(
            tips = tips,
            onTipClick = { tip -> tip.route?.let { onNavigateTo(it) } },
            modifier = modifier
        )
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsTipsCarousel(
    tips: List<SettingsTipData>,
    onTipClick: (SettingsTipData) -> Unit,
    modifier: Modifier = Modifier
) {
    if (tips.isEmpty()) return

    val itemsCount = tips.size
    val pagerState = rememberPagerState { itemsCount }
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current
    val spacing = 4.dp

    val carouselAnimationSpec = remember {
        spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow)
    }

    val autoScrollProgress = remember { Animatable(0f) }
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(pagerState.settledPage, itemsCount, lifecycleOwner) {
        if (itemsCount > 1) {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                autoScrollProgress.snapTo(0f)
                val startTime = System.currentTimeMillis()
                while (true) {
                    val elapsed = System.currentTimeMillis() - startTime
                    val p = (elapsed.toFloat() / 5000f).coerceIn(0f, 1f)
                    autoScrollProgress.snapTo(p)
                    if (p >= 1f) break
                    delay(16)
                }

                if (!pagerState.isScrollInProgress) {
                    val nextStep = (pagerState.currentPage + 1) % itemsCount
                    pagerState.animateScrollToPage(
                        page = nextStep,
                        animationSpec = carouselAnimationSpec
                    )
                }
            }
        } else {
            autoScrollProgress.snapTo(0f)
        }
    }

    val interactionSources = remember(itemsCount) { List(itemsCount) { MutableInteractionSource() } }

    val expressiveSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessLow
    )

    val visualProgress by remember {
        derivedStateOf { pagerState.currentPage + pagerState.currentPageOffsetFraction }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            val totalWidthPx = constraints.maxWidth.toFloat()
            val spacingPx = with(density) { spacing.toPx() }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                for (i in 0 until itemsCount) {
                    val dist = (visualProgress - i).absoluteValue
                    val currentWeight = when {
                        dist < 1.0f -> {
                            val maxW = if (i == 0 || i == itemsCount - 1) 0.9f else 0.82f
                            lerp(maxW, 0.1f, dist)
                        }
                        dist < 2.0f -> lerp(0.1f, 0.0f, dist - 1.0f)
                        else -> 0.0f
                    }

                    if (currentWeight > 0.005f) {
                        val currentCornerRadius = if (dist < 1.0f) lerp(24f, 16f, dist) else 16f
                        val currentAlpha = when {
                            dist < 1.0f -> lerp(1f, 0.4f, dist)
                            dist < 2.0f -> lerp(0.4f, 0f, dist - 1.0f)
                            else -> 0f
                        }

                        val baseColor = if (tips[i].isPrimary) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.84f)
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHighest
                        }

                        SettingsTipCard(
                            tip = tips[i],
                            dist = dist,
                            isToTheLeft = i < visualProgress,
                            interactionSource = interactionSources[i],
                            modifier = Modifier.weight(currentWeight),
                            containerColor = baseColor.copy(alpha = currentAlpha),
                            cornerRadius = currentCornerRadius.dp,
                            motionSpec = expressiveSpring,
                            onClick = { onTipClick(tips[i]) }
                        )
                    }
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .alpha(0f)
                    .pointerInput(itemsCount) {
                        detectTapGestures { offset ->
                            val tapX = offset.x
                            var currentX = 0f
                            val currentProgress = pagerState.currentPage + pagerState.currentPageOffsetFraction

                            val renderedWeights = (0 until itemsCount).map { i ->
                                val dist = (currentProgress - i).absoluteValue
                                when {
                                    dist < 1.0f -> lerp(if (i == 0 || i == itemsCount - 1) 0.9f else 0.82f, 0.1f, dist)
                                    dist < 2.0f -> lerp(0.1f, 0.0f, dist - 1.0f)
                                    else -> 0.0f
                                }
                            }

                            val visibleIndices = renderedWeights.indices.filter { renderedWeights[it] > 0.005f }
                            val totalGaps = (visibleIndices.size - 1).coerceAtLeast(0)
                            val availableWidthForCards = totalWidthPx - (spacingPx * totalGaps)

                            for (i in visibleIndices) {
                                val weight = renderedWeights[i]
                                val cardWidth = weight * availableWidthForCards

                                if (tapX >= currentX && tapX <= currentX + cardWidth) {
                                    coroutineScope.launch {
                                        val press = PressInteraction.Press(offset)
                                        interactionSources[i].emit(press)
                                        delay(150)
                                        interactionSources[i].emit(PressInteraction.Release(press))

                                        if (pagerState.currentPage == i) {
                                            tips[i].let(onTipClick)
                                        } else {
                                            pagerState.animateScrollToPage(
                                                page = i,
                                                animationSpec = carouselAnimationSpec
                                            )
                                        }
                                    }
                                    break
                                }
                                currentX += cardWidth + spacingPx
                            }
                        }
                    }
            ) {
                Box(Modifier.fillMaxSize())
            }
        }

    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun RowScope.SettingsTipCard(
    tip: SettingsTipData,
    dist: Float,
    isToTheLeft: Boolean,
    interactionSource: MutableInteractionSource,
    containerColor: Color,
    cornerRadius: Dp,
    modifier: Modifier = Modifier,
    motionSpec: SpringSpec<Float>,
    onClick: () -> Unit
) {
    val isFocused = dist < 0.6f
    val isPrimary = tip.isPrimary
    val contentColor = if (isPrimary) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    val iconColor = if (isPrimary) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.secondary
    }

    // Use health status directly for icon background if available, looks much cleaner than partial filling!
    val indicatorColor = if (tip.riskLevel != null) {
        when (tip.riskLevel) {
            RhythmGuardRiskLevel.LOW -> Color(0xFF4CAF50)
            RhythmGuardRiskLevel.MODERATE -> Color(0xFFFF9800)
            RhythmGuardRiskLevel.HIGH -> Color(0xFFFF5722)
            RhythmGuardRiskLevel.SEVERE -> MaterialTheme.colorScheme.error
        }
    } else null

    Card(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(cornerRadius))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {}
            ),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(cornerRadius)
    ) {
        AnimatedContent(
            targetState = isFocused,
            transitionSpec = {
                val springSpec = spring<IntOffset>(
                    stiffness = motionSpec.stiffness,
                    dampingRatio = motionSpec.dampingRatio
                )

                val slideIn = if (targetState) {
                    slideInHorizontally(animationSpec = springSpec) { if (isToTheLeft) -it else it }
                } else {
                    slideInHorizontally(animationSpec = springSpec) { if (isToTheLeft) it else -it }
                }

                val slideOut = if (targetState) {
                    slideOutHorizontally(animationSpec = springSpec) { if (isToTheLeft) it else -it }
                } else {
                    slideOutHorizontally(animationSpec = springSpec) { if (isToTheLeft) -it else it }
                }

                (fadeIn(animationSpec = spring(stiffness = motionSpec.stiffness, dampingRatio = motionSpec.dampingRatio)) + slideIn +
                    scaleIn(initialScale = 0.92f, animationSpec = spring(stiffness = motionSpec.stiffness, dampingRatio = motionSpec.dampingRatio)))
                    .togetherWith(
                        fadeOut(animationSpec = spring(stiffness = motionSpec.stiffness, dampingRatio = motionSpec.dampingRatio)) + slideOut +
                            scaleOut(targetScale = 0.92f, animationSpec = spring(stiffness = motionSpec.stiffness, dampingRatio = motionSpec.dampingRatio))
                    )
            },
            label = "TipCardContentTransition",
            modifier = Modifier.fillMaxSize()
        ) { focused ->
            if (focused) {
                // Card content layout (icon row, title, description) minus the close button
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = tip.icon,
                            contentDescription = null,
                            tint = indicatorColor ?: iconColor,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = tip.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = contentColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = tip.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = contentColor.copy(alpha = 0.85f),
                        lineHeight = 18.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.weight(1f))
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isToTheLeft)
                            MaterialSymbolIcon("chevron_left")
                        else
                            MaterialSymbolIcon("chevron_right"),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = contentColor.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}
